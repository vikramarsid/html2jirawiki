Credits
-------

This project uses Open Source and permissively licensed components. 
You can find the source code of their open source projects along with license and copyright information below. 
We acknowledge and are grateful to these developers for their contributions to open source.

* python-markdownify
  -  [Project: python-markdownify v0.4.1] https://github.com/matthewwithanm/python-markdownify
  -  Copyright Matthew Tretter.
 
 